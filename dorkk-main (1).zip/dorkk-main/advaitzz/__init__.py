# __init__.py
__version__ = "1.0"
